"""mftlab — laboratoire d'arbitrage statistique moyenne fréquence (Polars + Numba)."""
__version__ = "0.1.0"
